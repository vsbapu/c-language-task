#include<stdio.h>
 int main(){
    
    printf("welcome to red and white");
    return 0;
}